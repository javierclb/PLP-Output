from setuptools import setup

setup(
    name='PLP_Output',
    version='0.0.1',
    description='Libreria para tratamiento de salidas PLP',
    packages=['PLP_Output'],
    author='Javier De la Fuente Arce',
    author_email='jdelafuente@colbun.cl',
    keywords=['PLP'],
)